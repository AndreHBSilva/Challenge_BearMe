import Master from "./components/master/Master";

export default function App() {
    return (
        <>
            <Master/>
        </>
    )
}