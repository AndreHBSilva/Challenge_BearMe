import Calendario from '../../img/calendar.jpg'

export default function Agenda(props) {

  return(
    <img src={Calendario} alt="" width="100%" />
  )
}